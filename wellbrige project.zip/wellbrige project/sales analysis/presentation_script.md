# Final Presentation Script: Project 1 — Sales Analysis Dashboard

## Slide 1 — Introduction
“Hello everyone. My project is E-commerce Sales Performance Analysis. The objective is to understand sales performance by month, product category, region, and customer, and to turn the findings into practical business recommendations.”

## Slide 2 — Business Problem
“The business needs to know which categories and regions contribute the most revenue, how sales change over time, and which products and customers deserve attention.”

## Slide 3 — Dataset
“The practice dataset contains order IDs, dates, customer IDs, product names, categories, regions, quantities, unit prices, and sales. This project uses synthetic data for demonstration, so the results are illustrative rather than real-company findings.”

## Slide 4 — Data Cleaning
“I checked missing values and duplicate records, converted dates and numeric fields to suitable types, removed duplicate rows and invalid quantities, filled missing category and region values with ‘Unknown’, and recalculated sales as quantity multiplied by unit price.”

## Slide 5 — Analysis
“I calculated total sales, unique orders, average order value, unique customers, monthly revenue, sales by category and region, top products, and customer spend.”

## Slide 6 — Dashboard
“The dashboard uses KPI cards, a monthly sales line chart, category and region comparisons, and a top-products table. Slicers let a user filter by date, category, and region.”

## Slide 7 — Insights
“After running the analysis, I will report the actual results from my output files. I will identify the strongest category and region, the best-performing products, and any months with unusually high or low sales. I will not assume results before checking the data.”

## Slide 8 — Recommendations
“Possible actions include reviewing inventory for top products, investigating weak regions, planning campaigns around seasonal patterns, and creating targeted offers for high-value or inactive customers. The final recommendations should be supported by the actual charts.”

## Slide 9 — Limitations and Next Steps
“The practice data is synthetic and does not include product costs, returns, discounts, or marketing spend. With real data, I would add profit margin, returns, campaign performance, and a refreshable data pipeline.”

## Slide 10 — Conclusion
“This project demonstrates data cleaning, aggregation, visualization, dashboard design, and communicating business recommendations. Thank you. I am happy to answer questions.”
